# PHASE22: Strategy Matrix

**Date**: 2025-11-21  
**Phase**: PHASE22-1A  
**Source**: PHASE21-1C Actual Execution Report  
**Purpose**: Define validated strategy characteristics for Ensemble re-integration

---

## Executive Summary

This matrix consolidates PHASE21 validation results for 7 strategies. Each strategy was tested independently with its optimal timeframe and classified based on actual trade frequency.

**Key Insight**: Only **Scalping (3m)** is ACTIVE (high-frequency). The other 6 strategies are **LOW_FREQ** by design, requiring longer observation periods or specific market conditions.

---

## Strategy Matrix

| # | Strategy | Timeframe | Classification | Config File | Trades in Test | Characteristics |
|---|----------|-----------|----------------|-------------|----------------|-----------------|
| 1 | **scalping** | **3m** | **ACTIVE** | `phase21_scalping_solo.yml` | 31-33 trades/2min | High-frequency, short-term momentum |
| 2 | **reversion** | **5m** | **LOW_FREQ** | `phase21_reversion_solo.yml` | 0 trades/5-15min | Mean reversion (RSI 30/70), requires extremes |
| 3 | **swing_bb** | **5m** | **LOW_FREQ** | `phase21_swing_bb_solo.yml` | 0 trades/15min | Bollinger Band breakout, needs volatility |
| 4 | **breakout** | **15m** | **LOW_FREQ** | `phase21_breakout_solo.yml` | 0 trades/15min | Support/resistance breakout, infrequent |
| 5 | **daytrade** | **15m** | **LOW_FREQ** | `phase21_daytrade_solo.yml` | 0 trades/15min | Intraday trend, requires clear direction |
| 6 | **trend** | **1h** | **LOW_FREQ** | `phase21_trend_solo.yml` | 1 trade/3min | Long-term trend following, slow signals |
| 7 | **swing** | **1h** | **LOW_FREQ** | `phase21_swing_solo.yml` | 0 trades/15min | Multi-day swing, very low frequency |

---

## PHASE21 Validation Results

### ✅ ACTIVE Strategy (1)

#### 1. Scalping (3m)

**Test Duration**: 2-5 minutes  
**Trades**: 31-33 trades  
**Result**: High-frequency signal generation confirmed

**Infrastructure Validation**:
- ✅ 3m WebSocket reception
- ✅ FlowGuardian READY gate pass
- ✅ Config SSOT (effective_strategy/symbol/timeframe)
- ✅ Budget tracking operational

**Ensemble Role**: **Primary signal generator** - Expected to dominate Ensemble signal volume

---

### ⚠️ LOW_FREQ Strategies (6)

#### 2. Reversion (5m)

**Test Duration**: 5-15 minutes  
**Trades**: 0  
**Reason**: RSI conditions (< 30 or > 70) not met

**Infrastructure Validation**:
- ✅ 5m WebSocket reception
- ✅ FlowGuardian READY gate pass
- ✅ Strategy logic executes without errors

**Ensemble Role**: **Opportunistic** - Signals only during extreme oversold/overbought

---

#### 3. Swing_BB (5m)

**Test Duration**: 15 minutes  
**Trades**: 0  
**Reason**: Bollinger Band breakout conditions not met

**Ensemble Role**: **Volatility expansion** - Active during high volatility periods

---

#### 4. Breakout (15m)

**Test Duration**: 15 minutes  
**Trades**: 0  
**Reason**: No clear support/resistance levels broken

**Ensemble Role**: **Range breakout** - Active when price breaks key levels

---

#### 5. Daytrade (15m)

**Test Duration**: 15 minutes  
**Trades**: 0  
**Reason**: No clear intraday trend established

**Ensemble Role**: **Intraday momentum** - Active during clear directional moves

---

#### 6. Trend (1h)

**Test Duration**: 3 minutes  
**Trades**: 1 (validation of 1h feed)  
**Reason**: Long-term trend changes are slow

**Infrastructure Validation**:
- ✅ 1h WebSocket reception confirmed

**Ensemble Role**: **Trend filter** - Provides directional bias for shorter timeframes

---

#### 7. Swing (1h)

**Test Duration**: 15 minutes  
**Trades**: 0  
**Reason**: Multi-day swing patterns require longer observation

**Ensemble Role**: **Position trade** - Signals only for multi-day holds

---

## Timeframe Distribution

| Timeframe | Strategies | Count |
|-----------|------------|-------|
| **3m** | scalping | 1 |
| **5m** | reversion, swing_bb | 2 |
| **15m** | breakout, daytrade | 2 |
| **1h** | trend, swing | 2 |

**Implication for Ensemble**: Feed collector must support **multi-timeframe aggregation** (1m base → 3m/5m/15m/1h).

---

## Ensemble Configuration Principles

### 1. Single Symbol (PHASE22-1A)

**Symbol**: BTCUSDT (fixed)  
**Rationale**: Validate Ensemble infrastructure before multi-symbol expansion (PHASE23)

---

### 2. Timeframe Strategy

**Base Timeframe**: 1m (feed collector)  
**Aggregation**: 3m, 5m, 15m, 1h (per strategy requirement)  
**Verification**: PHASE22-1A smoke test must confirm multi-timeframe feed

---

### 3. Risk Parameters (PHASE21 Baseline)

**Portfolio**:
- Initial Balance: 10,000 USDT
- Max Open Positions: 3
- Max Exposure: 90%

**Position Sizing**:
- Default Risk Per Trade: 2%
- Mode: kelly_fraction
- Kelly Fraction: 0.25
- Leverage: 3x (max 5x)

**Risk Manager**:
- Max Daily Loss: 10% (20% in PAPER mode)
- Max Consecutive Losses: 10 (15 in PAPER mode)
- Cooldown: 60s (30s in PAPER mode)

**Note**: Flash Guard / cooldown tuning is **out-of-scope** for PHASE22-1A → Deferred to PHASE22-3

---

### 4. Expected Ensemble Behavior

**Signal Volume**:
- **Scalping**: Dominant (80-95% of signals)
- **Other 6**: Opportunistic (5-20% combined)

**Tier Distribution** (Predicted):
- **Tier 1 (High-Confidence)**: Scalping-dominated when score >= 0.8
- **Tier 2 (Consensus)**: Mixed signals when 2+ strategies agree
- **Tier 3 (Skip)**: Most of the time for LOW_FREQ strategies

**Success Criteria for PHASE22-1A**:
- ✅ No infrastructure errors during 10-20 min smoke test
- ✅ Multi-timeframe feed (3m/5m/15m/1h) reception confirmed
- ✅ FlowGuardian READY gate pass
- ✅ At least 1 Ensemble decision logged (Tier1/Tier2/Skip)
- ✅ ScorecardGenerator produces valid report with effective_* values

**Performance/PnL**: Not evaluated in PHASE22-1A (infrastructure focus only)

---

## Out-of-Scope (Future Phases)

### PHASE22-2: Extended Validation
- 12-24h REAL PAPER execution
- LOW_FREQ strategy signal verification over longer periods
- Portfolio behavior under multi-day operation

### PHASE22-3: Parameter Tuning
- Flash Guard parameter adjustment for PAPER environment
- Cooldown optimization per strategy
- Slippage model refinement

### PHASE23: Multi-Symbol
- Extend to Top N symbols (e.g., BTCUSDT, ETHUSDT, BNBUSDT)
- Symbol-specific strategy selection
- Cross-symbol portfolio risk management

### Future: Strategy Optimization
- Strategy parameter tuning (TP/SL/indicators)
- Factor weight optimization
- Regime classifier implementation
- ML-based meta-strategy

---

## Known Limitations

### 1. Scalping Dominance

**Issue**: Scalping (3m) generates 80-95% of signals, potentially drowning out LOW_FREQ strategies.

**Mitigation** (Future):
- Strategy-specific score multipliers
- Time-weighted consensus (favor longer timeframes during trends)
- Not addressed in PHASE22-1A

---

### 2. Multi-Timeframe Feed

**Issue**: Current `run_paper.py` extracts single `effective_timeframe` from config, but Ensemble needs 4 timeframes (3m/5m/15m/1h).

**Workaround for PHASE22-1A**:
- Set `timeframe: 1m` in Ensemble config
- Rely on feed collector's existing aggregation logic
- Verify in smoke test

**Proper Solution** (PHASE23+):
- Multi-timeframe feed collector
- Per-strategy timeframe specification

---

### 3. Regime Classifier

**Status**: Not implemented (regime = None)  
**Impact**: All strategies use regime_mult = 1.0 (neutral)  
**Future**: PHASE19-4 or later

---

## Next Steps

1. ✅ Complete Strategy Matrix (TASK 3)
2. Design `phase22_ensemble_single_symbol.yml` (TASK 4)
3. Execute smoke test (TASK 5)
4. Document results (TASK 6)
5. Git commit (TASK 7)

---

**Document Status**: ✅ COMPLETE  
**Next**: TASK 4 - Ensemble Config Design
