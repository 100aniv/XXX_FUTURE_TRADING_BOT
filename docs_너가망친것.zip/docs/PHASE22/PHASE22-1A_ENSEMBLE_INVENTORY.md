# PHASE22-1A: Ensemble Infrastructure Inventory

**Date**: 2025-11-21  
**Phase**: PHASE22-1A (Ensemble Re-integration)  
**Objective**: Map current Ensemble infrastructure and identify integration points with PHASE21 SSOT structure

---

## Executive Summary

This document inventories all Ensemble-related modules, configs, and their current state. It serves as the foundation for PHASE22-1A single-symbol Ensemble re-integration.

**Key Finding**: Ensemble infrastructure (PHASE19/20) exists and is functional, but needs verification against PHASE21 SSOT changes (effective_strategy/symbol/timeframe from cfg).

---

## 1. Ensemble Core Modules

### 1.1 Strategy Registry

**Location**: `common/registry/strategy_registry.py`  
**Purpose**: Auto-scan and register strategies with metadata  
**Key Features**:
- Auto-discovery of strategies in `strategies/` folder
- Metadata caching (optimal_regime, factor_weights, base_weight)
- Strategy instance creation API

**Status**: ✅ Implemented (PHASE19-1)

---

### 1.2 Score Engine

**Location**: `common/ensemble/score_engine.py`  
**Purpose**: Calculate strategy scores based on factors + regime  
**Calculation**:
```
factor_score = Σ (factor_i × weight_i)
regime_mult = 1.2 (optimal) | 0.3 (worst) | 1.0 (neutral)
final_score = base_weight × regime_mult × factor_score
final_score = clip(0, 1)
```

**Status**: ✅ Implemented (PHASE19-2)

---

### 1.3 Ensemble Aggregator

**Location**: `common/ensemble/aggregator.py`  
**Purpose**: Aggregate multiple strategy signals into final Ensemble decision  
**3-Tier Logic**:
- **Tier 1**: High-Confidence (score >= 0.8, conflict handling)
- **Tier 2**: Consensus (0.5 <= score < 0.8, 2+ votes)
- **Tier 3**: Skip (conditions not met)

**Key Classes**:
- `StrategyDecision`: Individual strategy signal + score
- `EnsembleDecision`: Final Ensemble decision
- `EnsembleAggregator`: Aggregation logic

**Status**: ✅ Implemented (PHASE19-3)

---

### 1.4 Factor Calculator

**Location**: `common/ensemble/factors.py`  
**Purpose**: Calculate 6 market factors from OHLCV data  
**Factors**:
1. Momentum (14-period ROC)
2. Volatility (14-period ATR %)
3. Volume (20-period SMA ratio)
4. Trend Strength (ADX)
5. Overbought/Oversold (RSI deviation)
6. Breakout Probability (Bollinger Band position)

**Status**: ✅ Implemented (PHASE19-2)

---

### 1.5 Individual Strategies

**Location**: `strategies/` folder  
**Current Strategies** (7 total):

| Strategy | File | Timeframe (PHASE21) | Classification |
|----------|------|---------------------|----------------|
| scalping | `scalping.py` | 3m | ACTIVE |
| reversion | `reversion.py` | 5m | LOW_FREQ |
| swing_bb | `swing_bb.py` | 5m | LOW_FREQ |
| breakout | `breakout.py` | 15m | LOW_FREQ |
| daytrade | `daytrade.py` | 15m | LOW_FREQ |
| trend | `trend.py` | 1h | LOW_FREQ |
| swing | `swing.py` | 1h | LOW_FREQ |

**Status**: ✅ Validated individually (PHASE21-1C)

---

### 1.6 Ensemble Strategy Module

**Location**: `strategies/ensemble.py`  
**Purpose**: Legacy ensemble portfolio manager (may need refactoring)  
**Note**: This file contains old ensemble logic that may conflict with new Aggregator-based approach. Needs review.

**Status**: ⚠️ Legacy code - Review required

---

## 2. Ensemble Configurations

### 2.1 Existing Ensemble Configs

| Config File | Purpose | Symbol | Timeframe | Duration | Status |
|-------------|---------|--------|-----------|----------|--------|
| `ensemble_paper_smoke.yml` | PHASE20-1 smoke test | BTCUSDT | 5m | 1h | ✅ Used in PHASE20-1 |
| `ensemble_paper_5min.yml` | 5min ensemble test | BTCUSDT | 5m | - | ⚠️ Legacy |
| `ensemble_paper_24h_multi.yml` | 24h multi-strategy | BTCUSDT | 5m | 24h | ⚠️ Legacy |

---

### 2.2 PHASE21 Single-Strategy Configs

| Strategy | Config File | Timeframe |
|----------|-------------|-----------|
| scalping | `phase21_scalping_solo.yml` | 3m |
| reversion | `phase21_reversion_solo.yml` | 5m |
| swing_bb | `phase21_swing_bb_solo.yml` | 5m |
| breakout | `phase21_breakout_solo.yml` | 15m |
| daytrade | `phase21_daytrade_solo.yml` | 15m |
| trend | `phase21_trend_solo.yml` | 1h |
| swing | `phase21_swing_solo.yml` | 1h |

**Key Insight**: Each strategy has its own validated timeframe. Ensemble config must respect these.

---

## 3. SSOT Integration Check

### 3.1 PHASE21 SSOT Changes

**run_paper.py** now uses:
```python
effective_strategy = cfg.get('strategy', {}).get('selector') or args.strategy
effective_symbol = cfg.get('symbol', args.symbol)
effective_timeframe = cfg.get('timeframe', args.timeframe)
```

**Impact on Ensemble**:
- ✅ `create_adapters()`: Uses `symbols=[effective_symbol]` → OK
- ✅ Strategy loading: Uses `effective_strategy` → OK
- ✅ ScorecardGenerator: Uses `effective_*` values → OK
- ⚠️ Ensemble multi-timeframe: Each strategy needs its own timeframe, but adapters use single `effective_timeframe`

---

### 3.2 Multi-Timeframe Feed Challenge

**Issue**: Ensemble runs 7 strategies with different timeframes (3m/5m/15m/1h), but `run_paper.py` currently:
- Extracts single `effective_timeframe` from config
- Passes `symbols=[effective_symbol]` to `create_adapters()`

**Potential Solution**:
1. Set `effective_timeframe = "1m"` (base timeframe)
2. Feed collector aggregates to 3m/5m/15m/1h
3. Each strategy receives its required timeframe

**Status**: ⚠️ **Needs verification in PHASE22-1A smoke test**

---

## 4. Engine Integration

### 4.1 Ensemble Mode Detection

**Location**: `execution/engine.py`  
**Detection Logic**:
```python
use_ensemble = cfg.get('strategy', {}).get('use_ensemble', False)
```

**Ensemble ON Flow**:
1. Load all 7 strategies
2. For each candle:
   - Compute factors
   - Score each strategy (ScoreEngine)
   - Aggregate signals (EnsembleAggregator)
   - Convert to engine signal format
3. Execute via Portfolio/Risk/Position modules

**Status**: ✅ Implemented (PHASE19-3), validated in PHASE20-1

---

### 4.2 Config-Based Threshold Control

**Config Section**: `ensemble`
```yaml
ensemble:
  enabled: true
  strategies: [scalping, breakout, reversion, trend, swing, swing_bb, daytrade]
  min_tier1_score: 0.8
  min_tier2_score: 0.5
  tier1_conflict_diff: 0.15
  min_tier2_votes: 2
```

**Status**: ✅ Implemented

---

## 5. Known Gaps & Limitations

### 5.1 Multi-Timeframe Feed

**Issue**: Each strategy requires different timeframe (3m/5m/15m/1h), but current feed collector uses single timeframe.

**Workaround for PHASE22-1A**:
- Set base timeframe to 1m
- Rely on existing aggregation logic
- Verify in smoke test

**Proper Fix** (Future):
- Multi-timeframe feed collector (PHASE23?)

---

### 5.2 Legacy Ensemble Code

**File**: `strategies/ensemble.py`  
**Status**: Contains old portfolio manager logic that may conflict with new Aggregator approach.

**Action**: Review and deprecate if not needed.

---

### 5.3 Regime Classifier

**Status**: Not implemented (placeholder = None)  
**Impact**: All strategies use regime_mult = 1.0 (neutral)  
**Future**: PHASE19-4 (Regime Classifier) → Out of scope for PHASE22-1A

---

## 6. PHASE22-1A Scope

### In-Scope

- ✅ Create single-symbol Ensemble PAPER config
- ✅ Verify Ensemble infrastructure works with PHASE21 SSOT changes
- ✅ Short smoke test (10-20 min) to validate infrastructure

### Out-of-Scope

- ❌ 12-24h extended validation → PHASE22-2
- ❌ Flash Guard/cooldown tuning → PHASE22-3
- ❌ Multi-symbol support → PHASE23
- ❌ Regime classifier implementation → Future
- ❌ Strategy parameter optimization → Future

---

## 7. Next Steps

1. ✅ Complete this inventory (TASK 2)
2. Create PHASE21 strategy matrix (TASK 3)
3. Design `phase22_ensemble_single_symbol.yml` (TASK 4)
4. Execute smoke test (TASK 5)
5. Document results (TASK 6)
6. Git commit (TASK 7)

---

**Document Status**: ✅ COMPLETE  
**Next**: TASK 3 - Strategy Matrix
